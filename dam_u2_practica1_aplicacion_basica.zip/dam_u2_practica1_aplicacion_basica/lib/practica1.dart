import 'package:flutter/material.dart';

class Practica1 extends StatefulWidget {
  State<StatefulWidget> createState(){
  return _Practica1();
  }
}

class  _Practica1 extends State<Practica1>{

  int NumeroTacos = 0;
  String MensajePedido = "";
  bool Cebolla = false;
  bool Cilantro = false;

  void Pedir() {

    MensajePedido = "Pidiendo: ${NumeroTacos} tacos";
    if(Cebolla==true || Cilantro==true){
      MensajePedido+= " con";
    }
    if(Cilantro==true){
      MensajePedido+= " Cebolla";
    }
    if(Cebolla==true){
      MensajePedido+= " Cilantro";
    }

    showDialog(context: context,
        builder: (BuildContext context){
          return AlertDialog(
            title: Text("Atendiendo:"),
            content: Text("${MensajePedido}"),
            actions: [
              TextButton(onPressed: (){
                Navigator.of(context).pop();
              },
                  child: Text("ok")
              )
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Practica 1"),
          actions: [
            Center(child: const Text("Reset"),),
            IconButton(onPressed: (){
              setState(() {
                NumeroTacos = 0;
                Cebolla = false;
                Cilantro = false;
              });
            }, icon: Icon(Icons.lock_reset)),
            SizedBox(height: 10,width: 30,),
          ],
        ),
        body: Column(
         mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("TAQUERIA EL CUATE", style: TextStyle(fontSize: 30, color: Colors.black),),
            SizedBox(height: 50,width: 10,),
            Text("TACOS: ${NumeroTacos}", style: TextStyle(fontSize: 15, color: Colors.black)),
            SizedBox(height: 20,width: 10,),
            Padding(padding: EdgeInsets.all(30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(onPressed: (){
                    setState(() {
                      NumeroTacos++;
                    });
                  }, icon: Icon(Icons.add)),
                  SizedBox(height: 10,width: 30,),
                  IconButton(onPressed: (){
                    if(NumeroTacos>0){
                      setState(() {
                        NumeroTacos--;
                      });
                    }
                  }, icon: Icon(Icons.remove)),
                ],
              ),),
            Padding(padding: EdgeInsets.all(30),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("Cebolla"),
                    Checkbox(value: Cebolla, onChanged: (bool? estado){
                      setState(() {
                        Cebolla = estado!;
                      });
                    })
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("Cilantro"),
                    Checkbox(value: Cilantro, onChanged: (bool? estado){
                      setState(() {
                        Cilantro = estado!;
                      });
                    })
                  ],
                )
              ],
            ),
            ),
            SizedBox(height: 20,width: 10,),
            ElevatedButton(onPressed: (){
              Pedir();
            }, child: const Text("PEDIR")),
          ],
        )
    );
  }
}